﻿using UnityEngine;
using System.Collections;

public class HeavyCubeDestroy : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider other){
		//print ("collidiert mit: "+other.gameObject.name);
		if(other.gameObject.name=="HeavyCube(Clone)"){
			Destroy(other.gameObject,1f);
		}
	}



}

