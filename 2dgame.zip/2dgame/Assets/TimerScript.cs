﻿using UnityEngine;
using System.Collections;

public class TimerScript : MonoBehaviour {

	public float remainingSeconds = 100;
	public bool doCountdown = false;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if(doCountdown){
		gameObject.guiText.text = "Zeit:  "+Mathf.Round(remainingSeconds);
		remainingSeconds-= Time.deltaTime;
		if(remainingSeconds<=0){
			remainingSeconds =0;
				BroadcastMessage("GameOver");
		}
		}else{
			gameObject.guiText.text = "Zeit: unbegrenzt";
		}



	}
}
