﻿using UnityEngine;
using System.Collections;

public class UmwerfButtonScript : MonoBehaviour {

	public GameObject parent;
	bool umfallen=false;
	bool isUmgefallen;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(umfallen){
			//parent.rigidbody.centerOfMass = new Vector3(0, 3, 0);
			parent.rigidbody.AddForce(new Vector3(150,0,0));
			BoxCollider[] boxes = parent.GetComponents<BoxCollider>();
			foreach(BoxCollider bc in boxes){
				bc.enabled =true;
			}
			isUmgefallen = true;
			gameObject.SetActive(false);
		}
	}

	void OnMouseDown() {
		print("MouseDown ok");
		umfallen=true;

	}


}
