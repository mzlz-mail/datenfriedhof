﻿using UnityEngine;
using System.Collections;

public class SheepRescuedTrigger : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider other) {
		print ("mit tuer kollidiert: "+other.gameObject.name);
		if(other.gameObject.name=="Schafskoerper"){
			transform.root.gameObject.BroadcastMessage("SheepRescued");
			Destroy(other.gameObject);
		}
		if(other.gameObject.name=="Shepard"){
			GameObject pm = GameObject.Find("PauseMenu");
			PauseMenuScript pms = pm.GetComponent<PauseMenuScript>();
			pms.gameIsPaused = true;

		}

	}


	void OnTriggerExit(Collider other) {
		if(other.gameObject.name=="Shepard"){
			GameObject pm = GameObject.Find("PauseMenu");
			PauseMenuScript pms = pm.GetComponent<PauseMenuScript>();
			pms.gameIsPaused = false;
		}
	}
}
