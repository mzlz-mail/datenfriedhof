﻿using UnityEngine;
using System.Collections;

public class InstantiateHeavyCube : MonoBehaviour {

	public GameObject heavyCube;

	// Use this for initialization
	void Start () {
	
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider other){
		if(other.gameObject.name=="Shepard"){
			GameObject clone = (GameObject) GameObject.Instantiate(heavyCube);
			clone.SetActive(true);
		}
	}
}
