﻿using UnityEngine;
using System.Collections;

public class DisableGravity : MonoBehaviour {

	public GameObject disableGravityOn;
	public bool enable;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider other){
		if(other.gameObject.name=="Shepard"){
			//cforce = addForceTo.AddComponent("ConstantForce") as ConstantForce;
			//cforce.force = new Vector3(0f,11f,0f);
			Rigidbody rb = disableGravityOn.AddComponent("Rigidbody") as Rigidbody;
			if(enable){
				rb.useGravity=true;
			}else{
				rb.useGravity=false;
			}

			rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ ;


		}
	}
}
