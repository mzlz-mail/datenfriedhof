﻿using UnityEngine;
using System.Collections;

public class SheepCounterScript : MonoBehaviour {

	public int sheepInLevel;
	public int collectedSheep =0;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		gameObject.guiText.text = "Schafe: "+collectedSheep+" von "+sheepInLevel;
	}

	void SheepRescued(){
		collectedSheep++;
	}
}
