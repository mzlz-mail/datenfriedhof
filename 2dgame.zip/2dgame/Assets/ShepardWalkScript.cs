﻿using UnityEngine;
using System.Collections;

public class ShepardWalkScript : MonoBehaviour {
	
	PauseMenuScript pms;

	// Use this for initialization
	void Start () {
		GameObject pm = GameObject.Find("PauseMenu");
		pms = pm.GetComponent<PauseMenuScript>();

	}
	
	// Update is called once per frame
	void Update () {
		GameObject[] objs = GameObject.FindGameObjectsWithTag("activatableObject");
		foreach(GameObject theobject in objs){
			Vector3 diff = theobject.transform.position;
			Vector3 p = gameObject.transform.position;
			float d = Mathf.Sqrt((diff.x-p.x)*(diff.x-p.x)+(diff.y-p.y)*(diff.y-p.y));
			UmwerfScript uw = theobject.GetComponent<UmwerfScript>();

			if(d<8){
				//print (theobject.name+" is nearest!");
				if(uw !=null){
					GameObject button = uw.button;
					if(button!=null){
						button.SetActive(true);
					}
				}
			}else{
				if(uw !=null){
					GameObject button = uw.button;
					if(button!=null){
						button.SetActive(false);
					}
				}
			}


		}

	}

	bool isOnGround(){

		float yh = collider.bounds.extents.y*1.7f;

		Vector3 down = transform.TransformDirection(Vector3.down);
		Vector3 lvect = transform.position;
		lvect.x-=collider.bounds.extents.x;

		Vector3 rvect = transform.position;
		rvect.x+=collider.bounds.extents.x;


		bool center=Physics.Raycast(transform.position,down,yh);
		bool left=Physics.Raycast(lvect,down,yh);
		bool right=Physics.Raycast(rvect,down,yh);

		return (left || center || right);

	}


	void FixedUpdate () {

		if(pms.gameIsPaused) return;

		if(Input.GetMouseButton(0)){
			Vector3 mousepos = Input.mousePosition;
			Vector3 mpos = Camera.main.ScreenToWorldPoint (new Vector3 (mousepos.x,mousepos.y,Camera.main.nearClipPlane));
			Vector3 shpos = gameObject.transform.position;

			Vector3 dirvect = mpos-shpos;
			dirvect.z=0;
			//float len = dirvect.magnitude;

			//dirvect = dirvect*(1.0f/len);

			if(isOnGround()){
				//print ("on ground");
				gameObject.rigidbody.AddForce(dirvect*20f);
			}


			
		}


	}


}
