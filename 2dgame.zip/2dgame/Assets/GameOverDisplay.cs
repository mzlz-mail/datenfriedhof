﻿using UnityEngine;
using System.Collections;

public class GameOverDisplay : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void GameOver(){
		//print ("game over");
		GameObject gotex = GameObject.Find("gameOverTexture");
		gotex.guiTexture.enabled =true;
	}
}
