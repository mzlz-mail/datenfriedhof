﻿using UnityEngine;
using System.Collections;

public class FollowShepardScript : MonoBehaviour {

	//die Hauptkamera dem angegebenen GameObject folgen lassen
	// übernimmt die Position des objekts "objectToFollow"


	public GameObject objectToFollow;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if(objectToFollow!=null){
			float x = objectToFollow.transform.position.x;
			float y = objectToFollow.transform.position.y;

			Camera.main.transform.position = new Vector3(x,y,100);

		}
	
	}
}
