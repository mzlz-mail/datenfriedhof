﻿using UnityEngine;
using System.Collections;

public class PauseBtn : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	

	void OnGUI () {
		if(GUI.Button(new Rect(10,700,64,64),"Optionen")){
			GameObject pm = GameObject.Find("PauseMenu");
			PauseMenuScript pms = pm.GetComponent<PauseMenuScript>();
			pms.gameIsPaused = true;

		}
	}





}
