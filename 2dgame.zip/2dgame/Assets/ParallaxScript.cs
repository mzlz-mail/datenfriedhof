﻿using UnityEngine;
using System.Collections;

public class ParallaxScript : MonoBehaviour {

	float x;
	public int offset;

	// Use this for initialization
	void Start () {
		x = Camera.main.transform.position.x;
	}
	
	// Update is called once per frame
	void Update () {
		transform.position = new Vector3((Camera.main.transform.position.x - x)/offset,transform.position.y, transform.position.z);
	}
}
