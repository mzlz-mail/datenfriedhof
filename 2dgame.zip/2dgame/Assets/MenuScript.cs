﻿using UnityEngine;
using System.Collections;

public class MenuScript : MonoBehaviour {

	enum Menustates {mainmenu, info, levelselect, ingame, pause};
	Menustates menustate = Menustates.mainmenu;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void InfoScreen(){

		if(GUI.Button (new Rect(500,320,300,50),"Zurück")){
			menustate = Menustates.mainmenu;
		}
	}


	void LevelSelect(){

		if(GUI.Button (new Rect(500,200,300,50),"Level 1")){
			Application.LoadLevel("2dgame");
		}
		
		if(GUI.Button (new Rect(500,260,300,50),"Level 2")){

		}

		if(GUI.Button (new Rect(500,320,300,50),"Zurück")){
			menustate = Menustates.mainmenu;
		}
	}


	void OnGUI(){
		if(menustate == Menustates.mainmenu){
			if(GUI.Button (new Rect(500,200,300,50),"Spiel starten")){
				menustate = Menustates.levelselect;
			}
			
			if(GUI.Button (new Rect(500,260,300,50),"Info")){
				menustate = Menustates.info;
			}
			
			if(GUI.Button (new Rect(500,320,300,50),"Beenden")){
				Application.Quit();
			}

		}else if(menustate == Menustates.info){
			InfoScreen();
		
		}else if(menustate == Menustates.levelselect){
			LevelSelect();
		}
	}
}
