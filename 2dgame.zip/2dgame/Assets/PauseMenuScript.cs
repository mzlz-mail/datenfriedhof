﻿using UnityEngine;
using System.Collections;

public class PauseMenuScript : MonoBehaviour {

	public bool gameIsPaused = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
			
	}

	void OnGUI(){

		if(gameIsPaused){

		if(GUI.Button (new Rect(400,200,300,50),"Level neu starten")){
				int currentLevel = Application.loadedLevel;
				Application.LoadLevel(currentLevel);
		}
		
		if(GUI.Button (new Rect(400,260,300,50),"Zurück zum Hauptmenü")){
				Application.LoadLevel("mainmenu");
		}
		
		if(GUI.Button (new Rect(400,320,300,50),"Weiterspielen")){
				gameIsPaused=false;
		}

		}
	}


	void GameOver(){
		gameIsPaused=true;
	}
}
